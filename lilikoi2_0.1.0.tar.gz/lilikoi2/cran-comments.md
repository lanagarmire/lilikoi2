This is a resubmission of a new package.

We addressed the reviewer's comments by adding a reference to our paper
describing our methods in the DESCRIPTION file, as well as adding
small executable @examples to some methods and a larger executable
workflow in README.md, lilikoiExample.r (on GitHub), and in the tests/
folder.

## Test environments
* Fedora 28: R 3.5.0
* Ubuntu 18: R 3.4.0
* win-builder: R-devel

## R CMD check results
There were no ERRORs or WARNINGs.

There is 1 note. Cannot find a message stating what size we should be under.

checking installed package size ... NOTE
  installed size is  5.0Mb
  sub-directories of 1Mb or more:
    data      3.8Mb
    extdata   1.1Mb
R CMD check results

## Downstream dependencies
There are currently no downstream dependencies for this package.
